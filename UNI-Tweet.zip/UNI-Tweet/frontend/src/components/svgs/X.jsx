const XSvg = (props) => (
	<svg aria-hidden='true' viewBox="0 0 100 100" {...props}>
      <circle cx="50" cy="20" r="5" fill="white"/>
      
      <path d="M30,40 Q50,80 70,40" stroke="white" stroke-width="10" fill="none" />
      <path d="M30,40 Q50,70 70,40" stroke="grey" stroke-width="5" fill="none" />

      <text x="50%" y="90%" text-anchor="middle" fill="white" font-size="10" font-family="Arial" letter-spacing="4">
        UNITWEET
      </text>
    </svg>
);
export default XSvg;
