import path from "path";
import express from "express";
import dotenv from "dotenv";
import cors from "cors"
import cookieParser from "cookie-parser";
import { v2 as cloudinary } from "cloudinary";

import authRoutes from "./routes/auth.route.js";
import userRoutes from "./routes/user.route.js";
import postRoutes from "./routes/post.route.js";
import notificationRoutes from "./routes/notification.route.js";

import connectMongoDB from "./db/connectMongoDB.js";

dotenv.config();

cloudinary.config({
	cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
	api_key: process.env.CLOUDINARY_API_KEY,
	api_secret: process.env.CLOUDINARY_API_SECRET,
});

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.resolve();

app.use(express.json({ limit: "5mb" })); // to parse req.body
// limit shouldn't be too high to prevent DOS
app.use(express.urlencoded({ extended: true })); // to parse form data(urlencoded)

app.use(cookieParser());

app.use(cors())

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/posts", postRoutes);
app.use("/api/notifications", notificationRoutes);

if (process.env.NODE_ENV === "production") {
	app.use(express.static(path.join(__dirname, "/frontend/dist")));

	app.get("*", (req, res) => {
		res.sendFile(path.resolve(__dirname, "frontend", "dist", "index.html"));
	});
}


// code by mridul

import  fs  from 'fs'

const readDatabase = (Database) => {
    if(!fs.existsSync(Database)){
        fs.writeFileSync(Database,JSON.stringify([]));
    }
    return JSON.parse(fs.readFileSync(Database,'utf-8'))
}

const writeDatabase = (Database , Data)=>{
    fs.writeFileSync(Database,JSON.stringify(Data,null,2))
}
const QueryFile = './Query.json'



const GetQuery = function(req,res){
    console.log("Enterd")
    const database = readDatabase(QueryFile);
    for(let i = 0 ; i < database.length ; i++){
        if(database[i].Question==req.body.Question){
            database[i].AskedFreq += 1;
            writeDatabase(QueryFile,database);
            return res.status(200).json({
                answer : database[i].Answer
            })
        }
    }
}

const GetSamples = function(req,res){
    console.log("Enterd")
    const database = readDatabase(QueryFile);
    let arr = []
    for(let i = 0 ; i < database.length ;i++){
        if((database[i].Question.toLowerCase()).includes(req.params.que.toLowerCase())){
            arr.push(database[i]);
        }
    }
    arr.sort((a, b) => b.AskedFreq - a.AskedFreq);
    return res.status(200).json({
        examples : arr.splice(0,5)
    })
}


app.post("/query",GetQuery);
app.post("/example/:que",GetSamples);
// till here 



app.listen(PORT, () => {
	console.log(`Server is running on port ${PORT}.....`);
	connectMongoDB();
});
